﻿using Xamarin.Forms;

namespace MasterDetailPageNavigation
{
	public partial class TodoListPage : ContentPage
	{
		public TodoListPage ()
		{
			InitializeComponent ();
		}
	}
}

