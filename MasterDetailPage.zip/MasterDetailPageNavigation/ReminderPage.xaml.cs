﻿using Xamarin.Forms;

namespace MasterDetailPageNavigation
{
	public partial class ReminderPage : ContentPage
	{
		public ReminderPage ()
		{
			InitializeComponent ();
		}
	}
}

