MasterDetailPage
================

This sample demonstrates how to use a `MasterDetailPage` and navigate between its pages of information.

For more information about the sample see [Master-Detail Page](http://developer.xamarin.com/guides/cross-platform/xamarin-forms/user-interface/navigation/master-detail-page/).

Author
------

David Britch
